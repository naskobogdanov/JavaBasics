zip -r src.zip src
mv src.zip src.jar
