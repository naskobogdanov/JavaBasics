I think that it was about the previous program (09.), but since I didnt soved it and that one is without a srat I just did it with my previous problem - 06. SumTwoNumbers
